<?php

$base_url = get_template_directory_uri() . '/builder-layouts/';

return array(
	array(
		"title" => "Shop Landing 1",
		"data"  => "shop-landing-1.zip",
		"thumb" => $base_url . "screenshot-shop-landing-1.jpg"
	),
	array(
		"title" => "Shop Landing 2",
		"data"  => "shop-landing-2.zip",
		"thumb" => $base_url . "screenshot-shop-landing-2.jpg"
	),
	array(
		"title" => "Shop Landing 3",
		"data"  => "shop-landing-3.zip",
		"thumb" => $base_url . "screenshot-shop-landing-3.jpg"
	),
	array(
		"title" => "Shop Landing 4",
		"data"  => "shop-landing-4.zip",
		"thumb" => $base_url . "screenshot-shop-landing-4.jpg"
	),
	array(
		"title" => "Shop Landing 5",
		"data"  => "shop-landing-5.zip",
		"thumb" => $base_url . "screenshot-shop-landing-5.jpg"
	),
	array(
		"title" => "Shop Landing 6",
		"data"  => "shop-landing-6.zip",
		"thumb" => $base_url . "screenshot-shop-landing-6.jpg"
	),
	array(
		"title" => "Shop Landing 7",
		"data"  => "shop-landing-7.zip",
		"thumb" => $base_url . "screenshot-shop-landing-7.jpg"
	),
	array(
		"title" => "Shop Landing 8",
		"data"  => "shop-landing-8.zip",
		"thumb" => $base_url . "screenshot-shop-landing-8.jpg"
	),
	array(
		"title" => "Shop Landing 9",
		"data"  => "shop-landing-9.zip",
		"thumb" => $base_url . "screenshot-shop-landing-9.jpg"
	),
	array(
		"title" => "Shop Landing 10",
		"data"  => "shop-landing-10.zip",
		"thumb" => $base_url . "screenshot-shop-landing-10.jpg"
	),
	array(
		"title" => "Shop Landing 11",
		"data"  => "shop-landing-11.zip",
		"thumb" => $base_url . "screenshot-shop-landing-11.jpg"
	),
	array(
		"title" => "Shop Landing 12",
		"data"  => "shop-landing-12.zip",
		"thumb" => $base_url . "screenshot-shop-landing-12.jpg"
	),
	array(
		"title" => "Shop Landing 13",
		"data"  => "shop-landing-13.zip",
		"thumb" => $base_url . "screenshot-shop-landing-13.jpg"
	),
	array(
		"title" => "Shop Landing 14",
		"data"  => "shop-landing-14.zip",
		"thumb" => $base_url . "screenshot-shop-landing-14.jpg"
	),	
);