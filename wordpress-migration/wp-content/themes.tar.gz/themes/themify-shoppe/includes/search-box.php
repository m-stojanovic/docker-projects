<div id="search-lightbox-wrap">
	<div class="search-lightbox">
		<div id="searchform-wrap">
			<?php get_search_form(); ?>
		</div>
		<!-- /searchform wrap -->
		<div class="search-results-wrap"></div>
	</div>
	<i id="close-search-box"></i>
</div>
<!-- /search-lightbox -->
