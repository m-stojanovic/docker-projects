<?php
/**
 * Deprecated codes
 *
 * @package Themify Builder
 */

/**
 * Themify_Builder_Updater
 * Updates are handled by Themify Updater plugin.
 *
 * @since 4.2.5
 */
class Themify_Builder_Updater {
	public function __construct( $name, $version, $slug ) {}
}
