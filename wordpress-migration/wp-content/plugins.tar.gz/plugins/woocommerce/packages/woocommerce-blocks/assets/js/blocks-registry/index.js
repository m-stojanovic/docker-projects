export { getRegisteredInnerBlocks } from './get-registered-inner-blocks';
export { registerInnerBlock } from './register-inner-block';
